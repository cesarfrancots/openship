import{v as e}from"./chunk-4N6VE7H7-B_5Pi1WN.js";function t(){throw e("/settings/general")}export{t as clientLoader};
