import{v as o}from"./chunk-4N6VE7H7-B_5Pi1WN.js";function e(){throw o("/mail/inbox")}export{e as clientLoader};
