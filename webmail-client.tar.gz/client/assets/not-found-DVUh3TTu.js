import{G as o}from"./chunk-4N6VE7H7-B_5Pi1WN.js";function e(){throw new Response("Not Found",{status:404})}const u=o(function(){return null});export{e as clientLoader,u as default};
