function n(){return null}export{n as P};
